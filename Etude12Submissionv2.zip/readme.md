COSC326 S1 2020
Etude 12 Drawing Bus Routes
William Wallace 1216661

Written in python

To compile, use the command:
javac BusRoutes.java Dijkstra.java Graph.java Node.java

To run/execute:
python drawing-busroutes.py filename.txt

TEST INPUT:
Christchurch, Dunedin
Christchurch, Rolleston, 5.5
Rolleston, Temuka, 15
Temuka, Timaru, 16.5
Timaru, Oamaru, 27
Christchurch, Palmerston, 10.5
Oamaru, Palmerston, 21.5
Palmerston, Dunedin, 23
Christchurch, Temuka, 20.6
Oamaru, St Bathans, 1
St Bathans, Dunedin, 2

OUTPUT:
Found in Graph.png file in current directory
